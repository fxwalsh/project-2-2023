# Simple Thingspeak Example

## Install

- install node.js
- Run ``npm intall request request-promise``

## Run

- Place Thingspeak Key in code where indicated
- Run ``node ts-request.js``